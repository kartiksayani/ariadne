# Handoff: Ariadne

## Overview

Ariadne is a local web app that sits on a second screen next to a terminal chat with an AI coding agent (claude-code CLI or codex CLI, both in iTerm). It turns the conversation into a **tree of items** (questions, decisions, findings, tasks and explanations), each a plain sentence with a clear status, grouped into **topics**. It answers three questions at a glance:

1. What is still waiting on me?
2. Where did this item come from, and what was decided?
3. What is the agent doing right now?

The user mostly reads and answers. The agent writes the items.

Hierarchy: **Project (a folder) → many Sessions → many Topics → many Items**. Topics and sessions are many-to-many: a topic starts in one session and can continue in later ones.

## About the design files

The files in this bundle are **design references built in HTML**. They are working prototypes that show the intended look and behaviour, not production code to copy. Recreate them in the target environment. If no codebase exists yet, a local web app (e.g. React + TypeScript, served by a small local Node/Bun process that also hosts the agent integration) is a sensible choice.

The prototypes run on scripted demo data and timers. Every "agent reply" is fake. See **Integration contract** for what the real system must do.

Open the files in a browser. `Ariadne Mockups.dc.html` is the full board, `Project Sessions.dc.html` is the app starting from the Projects screen, and `Ariadne.dc.html` is the app itself. The app's tweakable props select a scenario.

## Fidelity

**High fidelity.** Colours, type, spacing, states and interactions are final. Recreate them pixel-perfectly, using the Paperwhite tokens listed below.

---

## Screens / views

Frame IDs (1a, 1b, …) refer to `Ariadne Mockups.dc.html`. The target viewport is **1600 × 960** on a second screen.

### Global chrome (every screen)

Root grid rows: **48px header / 38px tab bar / 1fr body / 30px footer**.

- **Header (48px, bottom 1px divider).**
  - Left: the Ariadne mark (Phosphor `spiral`, 20px, accent) and "Ariadne" (15px/500, −0.01em).
  - Context text (12.5px, text at 64%), depending on the tab:
    - Projects: "3 projects".
    - Project: its path.
    - All sessions: "3 sessions open".
    - Session: "payments-sdk · started 14:02 · 18 messages".
  - Connection indicator: a 7px dot with a 3px glow ring (dot colour at 22%), plus text, e.g. "Connected · claude-code in iTerm · last message #18 at 15:04" or "codex isn't running · last message codex #19, yesterday 17:18".
  - Right side:
    - Search: 280px `.input`, 32px tall, magnifier inside, "/" key hint.
    - View switch Tree / Graph / Archive N (session tabs only): a segmented control with a 2px inset and 1px divider ring. The active segment gets text at 10%.
    - Messages toggle (`chats-teardrop`), accent when on.
    - Theme toggle (sun/moon). Both are 32px `.btn.btn-secondary.btn-icon`.
- **Tab bar (38px, background `--a-side`, bottom divider, scrolls horizontally).**
  - Tabs in order:
    - **Projects** (`folders`).
    - **All sessions N** (`squares-four`).
    - One tab per open session: "project / agent When", e.g. "payments-sdk / claude-code Today 14:02".
  - Session tab dot: filled green 9px circle when the agent is running, hollow when it isn't.
  - Each session tab has a × close button (22px). Closing a tab does not change the session.
  - Active tab: background `--a-bg`, 2px accent underline inset 8px each side.
- **Body grid columns:** `300px | minmax(560px,1fr) | [400px detail] | [240px message rail]`. The detail and rail columns appear only in session tabs. If the window is narrower, the body scrolls sideways.
- **Footer (30px, top divider, 11.5px, text at 62%):**
  - Key hints, each as a mono 10.5px keycap with a 1px inset divider ring: ↑↓ move · ←→ fold · a answer · 1–9 choose · ↵ send/details · b r d z o item actions · / search · g graph · m messages · esc close.
  - Right-aligned: "N items · N waiting on you · N in progress · N open · N archived topics".

### Waiting on me (left column, always visible, every project)

Frames 1a, 1c, 1l, 1m, 1t.

- Header: "Waiting on me" (15px/500), a count pill (accent at 18% background, `--a-acc-text`), and "Oldest first" right-aligned (12px muted).
- **Card** (12px padding, 8px radius, `--a-card`, 1px divider ring; when selected, a 1.5px ring of text at 45%):
  1. **Path** (12px, text at 60%): "payments-sdk › SDK cache PR › …". Collapsed to the first two parts, "…" and the last part if longer than four.
  2. Question (14.5px/21px).
  3. Ask, if any (13.5px, `--a-acc-text`), e.g. "Approve PR #757."
  4. Earlier-session note when relevant: "Asked in an earlier codex session. Your answer goes to claude-code, with this item's context."
  5. "Round 3 · last time you replied '…'" when there have been several rounds.
  6. Delivery line when the send failed (warn colour), with a Retry button.
  7. **Answer control, compact** (see Components).
  8. Footer: clock icon, "Waiting 28 min · asked in #16", and a ghost **Details** button.
- **Sent** subsection below: answered items waiting for the agent to pick them up, each with a 2-line question and a delivery line.
- Empty: green check-circle, "Nothing waiting on you", then "New questions from the agent will appear here."
- Sort by when the item entered Waiting, on one clock across sessions (yesterday sorts before today). Items in archived topics or closed sessions are excluded.

### 1. Projects screen (first tab) — frames 1ab, 1p

- Title "Projects" (18px/500) and the subtitle "3 folders with claude-code or codex sessions · found automatically".
- Grid: `repeat(auto-fill, minmax(320px,1fr))`, 12px gap.
- **Project card** (16px padding, 8px radius, `--a-card`; 1px ring of accent at 45% if anything is waiting, otherwise divider):
  - Folder icon (20px, accent), name (15.5px/500), path (mono 11.5px, text at 60%).
  - 2×2 grid of 12.5px facts:
    - "2 active · 2 closed".
    - Running dot plus "1 agent running" or "No agent running".
    - "1 waiting on you" (`--a-acc-text`) or "Nothing waiting".
    - "Last activity today 15:04".
  - Agent chips (22px, 1px divider ring, terminal icon).
- First launch (1p) adds an accent-tinted banner: "Ariadne found these projects in your claude-code and codex session folders. Open one to see its sessions."

### 2. Project page — frame 1ac

- "← Projects" ghost button, then the project header: folder icon, name 16px/500, mono path.
- Sections **Active sessions · N** and **Closed · N** (11px/500 uppercase labels, 0.07em tracking).
- **Session card** (12px/14px padding, 8px radius; active `--a-card`, closed transparent with a divider ring):
  - Terminal icon, "claude-code · iTerm window 1" (14px/500), meta "Today 14:02 – now · 18 messages" (adds " · read-only" when closed).
  - Running indicator.
  - Actions:
    - Active: **Open in a tab** (primary), or **Go to tab** if already open, plus **Close session** (ghost).
    - Closed: **Reopen**.
  - Topic chips (24px, text at 6% background): name plus counts ("1 waiting · 2 closed", "archived", "continued later").

### 3. All sessions tab — frame 1z

The same session-card groups, one group per project that has an open tab. Each group header has an "Open project" link.

### 4. Session tab — tree view (main) — frames 1a, 1b, 1t, 1u, 1w

- **Session bar** at the top of the column: terminal icon, "codex · iTerm window 2", "Yesterday 16:40 – 17:25 · 2 topics", running indicator, and **Close session** (ghost). Close session only marks the session Closed in Ariadne; it never touches the agent process.
- **Filter bar:** status chips All · Waiting on me · Open · In progress · Closed (28px tall, 7px radius, icon + label + count; active: accent at 14% background and a 1px accent-at-55% ring). Then a topic select on the right.
- **Banners** (8px radius, text at 6% background, 1px inset divider), only when they apply:
  - "Showing an item outside your current filters." with **Resume filtered view**.
  - "Archived 'X'." with **Undo** and **View archive**.
- **Topic row:**
  - Chevron, name (15.5px/500).
  - Session chip when the topic comes from another session ("codex · yesterday", "Continued from codex · yesterday").
  - Counts with status icons ("1 waiting on you · 1 open · 8 closed").
  - On hover or select: **Continue here** (earlier topics) and **Archive** (`e`).
  - All closed: "Everything here is closed. **Archive topic**".
- **Item row** (see Components). Indent 24px per level. Guide lines at x = 20 + 24k.
- **The thread:** the selected item's ancestor guides turn accent (1.5px) from the topic down to it, ending in a rounded elbow (radius 7px, 20px tall) into its chevron or icon.
- Branches expand or collapse **once, at load**:
  - Collapsed: branches where the item and everything under it are closed.
  - Expanded: everything else.
  - Live status changes never collapse a branch while you read. Search and filters expand paths to matches temporarily.

### 5. Item detail (400px column) — frames 1b, 1e, 1l, 1q, 1u, 1v

From top to bottom; empty sections are omitted:

1. **Breadcrumb**, one clickable button per ancestor.
2. Status badge, then meta "Decision · next action: you · raised in #10".
3. Question as a 20px/500 heading (line-height 1.4).
4. **Your answer / Your request** stepper: Sending → Received → In progress → Resolved. Labels can read "Queued", "Not delivered" or "Checking…". Dots are 10px, the current step has an accent ring, connectors are 1.5px. Under it, a delivery line with Retry when the send failed.
5. **Actions for statuses other than Waiting:**
   - Open: "Not discussed yet". Bring it up (b, primary), Reply (r), Drop (d), Later or Unpark (z).
   - In progress: "While the agent works". Add a note (r).
   - Closed: "Revisit". Follow up (r), Back to Open (o).
   - Text boxes: reply, note and follow-up are textareas (⌘↵ sends). The drop reason is an input (Enter drops). Each has a hint line.
6. **Answer control, full**, for Waiting items. Shown with the ask.
7. **Outcome**, under its status label in the status colour, 15px/1.6.
8. Agent note (progress colour, robot icon).
9. **Why** (14px).
10. **Before you reopened it**: previous status and outcome.
11. **Replaced by**: a link card with the target's status.
12. **Branched into N items**: children with status icons.
13. **Back and forth · N rounds**: one card per round showing what the agent asked, what you chose or replied, and what it did. Branches forked in that round are listed as links (`git-fork` icon). The current round has an accent-at-7% background and a "Waiting on you" tag.
14. **Links**: PR, file and doc icons.
15. **Timeline**: Message excerpts with roles, deduplicated by message. Roles: Parent raised here, Agent raised this or You asked here, You replied, Agent updated.
16. Footer: "Agent reference `1.3.1.2`" and **Copy reference** (copies "1.3.1.2 — question").

### 6. Answering inline — frame 1c

Press `a`, or click an option on a card. The row expands into a full answer control with a 1px accent-at-50% ring and a 28px accent glow. The **recommended option is pre-selected**, so Enter sends it.

### 7. Graph view — frames 1d, 1f, 1aa

- One graph per topic in the current session tab. Each is a card with its own header (name, session chip, counts).
- Layout: left to right. Nodes are 190×66px, 8px radius, with a status icon, short title (12.5px/500), a two-line question (11.5px) and, on collapsed nodes only, a "+N" pill counting the items below. Clicking a collapsed node selects it and opens the next tier of its branches (its direct children; their own branches stay collapsed with their own "+N"), and its pill disappears. Expanded nodes with branches show a small "−" button in the same spot that collapses them again (if the selection was inside, it moves to that node). Expansion is shared with the tree.
- Edges: Bezier curves, text at 24%, 1.25px. The selected path is accent, 1.75px.
- Waiting nodes: 1px accent ring and a 22px accent glow. Closed nodes: transparent and muted. Nodes that don't match filters: 40% opacity.
- Replaced: a dashed arc labelled "replaced by", ending in an arrowhead.
- Follows the tree's expansion and filters. **Reveal selected** scrolls to the selected node. A legend sits above.

### 8. Message rail (240px, optional, `m`)

- Messages for the current session tab, newest at the bottom. Each has `#n`, author, time and a 3-line excerpt.
- Hovering a message highlights the items it touched. Clicking pins the highlight.
- Hovering or selecting an item highlights its messages.
- **Following latest:** if you scroll up, new messages don't move the view. A pill "N new messages · Jump to latest" appears instead.

### 9. Archive — frame 1x

- The Archive view of the current tab's project(s).
- One card per archived topic: name, meta "From codex · 3 days ago · archived 2 days ago · 3 decided · 1 done · 1 dropped", up to three outcomes with status icons, "and N more".
- Actions: **Restore** and **Continue in this session**.

### 10. Dialogs (`.dialog`, top elevation, backdrop of neutral-900 at 55%)

- **Continue in this session** (1y): shows the summary Ariadne sends the new agent, grouped Waiting on you / Open or in progress / Decided or done / Dropped or replaced, each line with its reference ID. Buttons: Cancel and "Send to claude-code".
- **Agent isn't running** (1ad): "codex isn't running for this session". Two option buttons:
  - "Send it to claude-code now" (the running session in the same project picks up the topic, then gets the answer).
  - "Queue it for codex" (delivered when it runs again; shows Queued).
  - Plus Cancel. Asked **every time**.

- **Remove** (all four kinds): trash icon in `--a-danger` beside the title, a one-paragraph body, a warning line in `--a-danger` when questions waiting on you would go too ("2 questions waiting on you go with it."), then Cancel and an outlined danger button ("Remove item", "Remove 3 items", "Remove topic", "Remove session", "Remove project"). Enter confirms, Esc cancels. See Remove below.

### 11. Empty, loading and edge states

- **1g:** no items yet.
- **1h:** loading skeletons, "Reading the session…".
- **1i:** all clear.
- **1o:** reconnecting. Your choice is kept and sending is disabled with an explanation.
- **1m:** delivery failed with Retry, and "Checking delivery…" after an interruption.
- **1n:** revealed outside filters.

---

## Components

- **Status Badge.** Variants: `icon`, `pill` (icon + label) and `text` (label only); 22px tall, 6px radius, 12px/500. Background is the status colour at 14%, text in the status colour. Each status has its own **shape**, never colour alone:
  - Open: `circle`.
  - Waiting on me: `question` (fill).
  - In progress: `circle-half`.
  - Decided: `check-circle`.
  - Done: `check-circle` (fill). Explanations show "Explained".
  - Dropped: `x-circle`.
  - Replaced: `arrow-circle-right`.
  - Later is a flag on Open items, shown as the label "Later".
- **Item Row.**
  - Padding: 9px top, 14px right, 10px bottom, left 12 + 24×depth px.
  - Chevron (16×22) only if the item has children, then the status icon (17px), then content.
  - Question: 15px/22px. Muted (text at 64%) when closed, parked for later, or shown only as context for a filter. Never fade the whole row with opacity.
  - **Exactly one supporting line**, by priority:
    1. Delivery state.
    2. Parked for later.
    3. Ask (`--a-acc-text`).
    4. Agent note (progress colour).
    5. Replaced by [link] plus the target's status.
    6. Outcome (arrow-elbow icon in the status colour, text at 84%).
  - Then a collapsed summary if folded ("2 open · 5 closed inside"), and the inline answer control if answering.
  - Right side: hover actions (26×24 icon buttons), "Round 3", the mono item ID (visible on hover or select), and a text badge.
  - States:
    - Selected: neutral tint (text at 7%).
    - Keyboard focus: inset 1.5px accent-at-80% ring.
    - Touched by the hovered message: accent at 9% plus a 2px accent bar.
    - Search match: highlighted text (accent at 32%).
- **Answer Control.** Compact (stacked) or full (grid `repeat(auto-fit,minmax(220px,1fr))`).
  - **Option button:**
    - Number keycap (18px).
    - Label (13.5–14px/500).
    - "★ Recommended" plus the consequence (12.5–13px, text at 68%).
    - The recommended option uses `.btn-primary` (accent outline); the others use `.btn-secondary`.
    - Selected: accent at 10% background, accent ring, 18px glow, and a filled check.
  - **Send row:** "Send 'Approve' ↵" (primary) plus the hint "1–2 to change · Enter sends · Esc closes, keeps your draft".
  - **Full mode** adds a textarea "Or reply in your own words…" and **Send reply** (⌘↵). A reply never also sends the selected option.
  - Optional warn line (warn colour at 12%) and blocked line (wifi-slash icon).
- **Message Excerpt.**
  - Rail variant: 2px left bar, accent when highlighted or active, background accent at 8% or 15%.
  - Timeline variant: 9px dots (filled accent for "created", ringed otherwise, neutral ring for "origin"), a 1px connector, a role label (500, `--a-acc-text`), a session tag ("codex #19"), and "Yesterday 17:18".

## Interactions and behaviour

### Keyboard

The workspace keys work only when the app (not a text field) has focus.

- **Move and fold:** ↑/↓ or j/k move between visible rows. ← or h collapses, or goes to the parent. → or l expands, or goes to the first child.
- **Enter:** sends the selected option while answering; otherwise opens detail (or toggles a topic).
- **Answering:** `a` answers the selected item, or jumps to the oldest waiting one. 1–9 select an option (they never send).
- **Item actions:** b bring up · r reply, note or follow-up (depending on status) · d drop · z later/unpark · o back to Open · e archive topic.
- **Views and search:** `/` or ⌘F search, g switches tree and graph, m toggles messages.
- **Esc:** closes the answer box, then detail, then clears filters. Drafts are always kept.
- **⌫ / Delete:** remove the selected item or topic (asks first).

### Links

Every link (breadcrumb, child, replacement, waiting card, graph node) does the same thing: select the item, expand its ancestors, open the right session tab (opening one if needed), scroll it into view and open detail. If the current filters hide it, show it anyway with the "outside your current filters" banner.

### Search and filters

- Search covers question, outcome and short label. It's case-insensitive, and several words must all match.
- Matches show with their parents as muted context.
- Chip counts follow the search and topic filter, but not the status chip itself.

### Live updates

Never reorder rows, steal focus or collapse branches. Only counts and rows change.

## State model

### Item status

Only the **agent** changes it. See `Status Diagram.dc.html` for the transition diagram and rules.

- Statuses: **Open, Waiting on me, In progress, Decided, Done, Dropped, Replaced** (the last four are "Closed").
- Main transitions:
  - Open → Waiting: the agent asks, or you pressed Bring it up.
  - Open → In progress: the agent starts, or after your Reply.
  - Waiting ↔ In progress.
  - Any → closed.
  - Closed → Open: Back to Open.
  - In progress → Open: rare.
- **Closed isn't a dead end:**
  - Follow up adds a comment, or opens a **child branch** if it's a new question.
  - Back to Open reopens it; the old outcome is kept as `prev`.
- **Rounds vs children:** refining the same decision stays on the item as a round. A new question becomes a child item, even mid-discussion, and the parent keeps going.
- **Later** is a local flag on Open items. It isn't a status and is never sent to the agent.

### Delivery

Tracked per submission, separately from status.

- Stages: Sending → Received → (the agent changes status). Also **Queued** (agent not running), **Failed** (Retry; the answer is kept) and **Checking** (after an interruption; reconcile before allowing a retry).
- No Undo for anything sent to the agent. Retries must not create duplicate answers.

### Session status

- Session status is **Active** or **Closed**, set in Ariadne.
- **Running** or not is detected from the agent, independently.
- Closed sessions are read-only, their tabs close, and they move to the project's Closed list; Reopen makes them active.

### Remove

Remove is permanent, unlike Archive (topics) or Close (sessions). The conversation so far and files on disk are never changed. Every remove asks first, then shows a note above the main column.

- **Items and topics are told to the agent** of the session they belong to (the session their messages go to), so it stops working on them and won't bring them up again. The note gives a 5-second undo window first: "Removed “Stale plans” and 4 items below it. claude-code is told in 5 seconds unless you undo." (hourglass, **Undo**). Then it follows the delivery stages: "Telling claude-code…" → "claude-code was told and won't bring them up again." (green check, Dismiss). No Undo once it's sent.
  - Agent not running: same 5-second window, then "claude-code isn't running; it's told when it runs again." It's delivered with the queue.
  - Session closed: nothing is sent ("The session is closed, so codex isn't told."), and Undo stays until the next remove or Dismiss.
- **Sessions and projects** are removed from Ariadne only; no agent is told. Undo stays until the next remove or Dismiss.

- **Item:** row hover action (trash, last), the trash button in the detail header, or ⌫/Delete on the selected item. Removes the item and everything below it.
- **Topic:** **Remove** in the topic header's hover actions, **Remove** on an archived topic card, or ⌫/Delete with the topic header selected. Removes the topic and its items in every session.
- **Session:** **Remove** (ghost) on every session card, active or closed. Removes the session, closes its tab, and removes topics that belong only to it; topics shared with other sessions stay and lose this session.
- **Project:** trash icon at the top right of each project card, and **Remove project** in each project group header. Removes the project with its sessions, topics and items, and closes their tabs. It's listed again only if a new session starts in that folder.
- The dialog body says which of these applies ("claude-code is told, so it stops working on it…", "…isn't running, so it's told when it runs again", "The session is closed, so codex isn't told").
- `--a-danger`: dark oklch(0.74 0.13 28), light oklch(0.52 0.15 28). Used only for remove.

### Topic

- Archived or not. Archiving hides the topic from the tree and its questions from Waiting on me. Restore brings it back.
- **Continue in this session** sends the running agent a summary; afterwards the topic belongs to both sessions.

### UI state to persist

Open tabs, active tab, selection, expansion, filters, drafts, unresolved submissions, theme, rail on or off, and scroll positions.

## Data model

```
Project   { id, name, path, lastActivity }                       // auto-discovered folders
Session   { id, projectId, agent: 'claude-code'|'codex', where, startedAt, endedAt?,
            status: 'active'|'closed', running: boolean }         // running is detected
Topic     { id, projectId, name, short, sessionIds[], from?, continued?, archived, archivedAt? }
Item      { id /* immutable agent reference, e.g. "1.3.1.2" */, topicId, parentId,
            short, type: question|decision|finding|task|explanation,
            status, owner /* who acts next: me | agent | <name> */,
            question, outcome, why, ask, note, later?,
            createdIn: messageId, updatedIn: messageId[], waitingSince?: messageId,
            links[{kind: pr|file|doc, label, meta}],
            options[{id, label, consequence, recommended}],
            replacedBy?, rounds[{ask, you?{chosen, text}, result?, forks[itemId], msgs[]}],
            prev?{status, outcome} }
Message   { id, sessionId, number /* per session */, author: me|agent, at, excerpt, fullText? }
Submission{ id, itemId, itemRevision, kind: answer|bring|reply|drop|note|followup|reopen|continue,
            optionId?|text?, stage: queued|sending|received|failed|checking, error? }
```

Breadcrumbs and paths are worked out from parent links; never parse them from IDs. In the prototype, scripted agent responses live in `DEMO`, `BRING` and the timers. They are not part of `options`.

## Integration contract (mechanism left to the implementer)

- **Discovery.** Projects and sessions come from the claude-code and codex session folders on disk (both CLIs write per-session transcripts). Group sessions by working directory. Check the current CLI docs for exact paths and formats.
- **Writing items.** Recommended: a local **MCP server** run by Ariadne, which both CLIs can connect to. It offers tools such as `upsert_item`, `set_status`, `add_round` and `link_message`. Add instructions to `CLAUDE.md` and `AGENTS.md` telling the agent to record items as it works.
- **Liveness.** "Agent running" means the agent's MCP connection is open (fall back to transcript activity). Show it apart from Active/Closed, and apart from last-message time.
- **Delivering answers.** Recommended **pull**: Ariadne queues the submission, and the agent fetches pending answers with an MCP tool each turn (a hook or the instructions file makes it check). "Received" means the agent actually fetched it. Optionally, Ariadne can type into the iTerm tab via AppleScript; treat that as "typed", not "received". Never show Received or In progress without confirmation from the agent.
- **Not running.** Ask each time: send to a running session in the same project (with the topic summary) or queue it.

## Design tokens (Paperwhite)

Tokens come from `_ds/paperwhite/styles.css` (dark ground at `:root`) and the `THEMES` object in `Ariadne.dc.html` (app roles, status colours, light overrides). Use the variables. The look is an e-reader page: matte warm paper, soft ink, one calm cobalt accent, light shadows.

### Dark (default)

- Ground and text:
  - `--color-bg` oklch(0.2 0.006 80).
  - `--color-surface` oklch(0.25 0.007 80).
  - `--color-text` oklch(0.9 0.012 85).
  - `--color-accent` oklch(0.7 0.12 255).
  - `--color-divider` = text at 14%.
- Ramps share one lightness scale, 100→900: L 0.975 0.935 0.875 0.79 0.69 0.585 0.48 0.38 0.29.
  - Neutral: hue 80, chroma 0.008.
  - Accent: hue 255, chroma 0.13 scaled by 0.2 0.4 0.65 0.85 1 1 0.9 0.75 0.55.
- App roles:
  - `--a-bg` = bg.
  - `--a-side` oklch(0.225 0.006 80): side panels and topic header bands.
  - `--a-card` = surface.
  - `--a-acc-text` = accent-300.
  - `--a-guide` = text at 20% (tree guide lines and elbows).
  - `--a-edge` = text at 26% (graph edges).
  - `--a-lift` = `--shadow-sm` (added under every card's 1px divider ring).
  - `--a-warn` = oklch(0.8 0.11 55).
- Status colours:
  - Open: neutral-400.
  - Waiting: accent-400.
  - In progress: oklch(0.82 0.09 78).
  - Decided: oklch(0.8 0.075 178).
  - Done: oklch(0.8 0.085 148).
  - Dropped and Replaced: neutral-500.

### Light

- Ground and text:
  - bg oklch(0.958 0.009 85), matte paper.
  - surface oklch(0.978 0.007 85), cards sit slightly brighter than the page.
  - text oklch(0.27 0.008 75), soft ink.
  - accent = accent-600.
  - divider = text at 12%.
- App roles:
  - `--a-side` oklch(0.938 0.01 85).
  - `--a-acc-text` = accent-700.
  - Guide lines = text at 20%.
  - Warn = oklch(0.55 0.14 45).
- Status colours:
  - Open: neutral-600.
  - Waiting: accent-600.
  - In progress: oklch(0.55 0.11 68).
  - Decided: oklch(0.52 0.08 185).
  - Done: oklch(0.52 0.1 148).
  - Dropped and Replaced: neutral-700.

### Type, spacing, radius, shadows, states

- **Type.** JetBrains Mono 400/500 only (never bolder) for everything, including IDs and keys. Sizes:
  - 20: detail heading.
  - 18: page titles.
  - 15.5: topic and project names.
  - 15: item questions.
  - 14 to 14.5: body.
  - 13 to 13.5: secondary.
  - 12 to 12.5: meta.
  - 11 / 11.5: labels and mono. Section labels are 11px/500 uppercase with 0.07em tracking.
- **Spacing.** A 0.7× scale (2.8, 5.6, 8.4, 11.2, 16.8, 22.4px); the prototypes mostly use 6/8/10/12/14/16px.
- **Radius.** 3px (`--radius-sm`), 5px (`--radius-md`: cards, buttons, nodes), 8px (`--radius-lg`: dialogs). Badges and chips 6px.
- **Shadows.** Soft and warm-tinted, never a hard edge.
  - `--shadow-sm` (cards): dark 0 1px 2px rgba(0,0,0,.22), 0 4px 14px rgba(0,0,0,.18); light 0 1px 2px and 0 3px 10px of oklch(0.35 0.02 80) at 7% and 6%.
  - `--shadow-md` (popovers): a 1px edge plus 0 10px 30px; dark rgba(0,0,0,.4), light oklch(0.35 0.02 80 / .14).
  - `--shadow-lg` (dialogs): a 1px edge plus 0 18px 48px; dark rgba(0,0,0,.5), light oklch(0.35 0.02 80 / .18).
- **Tree.** Each item draws a 1px elbow from its parent's guide at x = 20 + 24 × (depth − 1); a parent's vertical line continues only while later siblings follow. The selected item's ancestor chain draws over them in accent at 1.5px. Topic headers are a band of `--a-side` with a divider rule above and below, and 20px of space before every topic but the first.
- **States.** Primary buttons are an accent **outline**, never filled. Focus is `:focus-visible` with a 2px accent outline. Disabled is 45% opacity.

## Assets

- Icons: **Phosphor** web font v2.1.1, regular and fill weights (`https://unpkg.com/@phosphor-icons/web@2.1.1/src/{regular,fill}/style.css`).
- Font: JetBrains Mono, loaded by the Paperwhite stylesheet.
- No images.

## Files

- **App:** `Ariadne.dc.html`. Scenario props: default, projects, projectpage, sessions, session, notrunning, review, thread, project, archive, continue, sent, failed, reveal, reconnecting, first; plus theme, view and rail.
- **Board:** `Ariadne Mockups.dc.html`, with every frame (1a–1aa, 1ab–1ad).
- **Entry pages:** `Project Sessions.dc.html` (Projects screen), `Project Scenario.dc.html`, `Thread Scenario.dc.html` and `PR Review Scenario.dc.html`.
- **Reference:** `Status Diagram.dc.html` (status, delivery and topic/session transitions, with rules) and `Component Sheet.dc.html` (dark and light).
- **Components:** `Status Badge.dc.html`, `Item Row.dc.html`, `Answer Control.dc.html` and `Message Excerpt.dc.html`.
- **Runtime:** `support.js` (the prototype runtime only) and `_ds/paperwhite/styles.css` (tokens and component classes).

### Not designed yet

- Layout for windows under 1000px.
- Resizable panels.
- A shortcut help overlay.
- Sending a correction after an answer was received.
- Notifications.
